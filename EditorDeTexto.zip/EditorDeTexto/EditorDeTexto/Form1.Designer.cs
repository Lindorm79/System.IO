﻿namespace EditorDeTexto
{
    partial class Form1
    {
        /// <summary>
        ///  Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        ///  Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        ///  Required method for Designer support - do not modify
        ///  the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            botaoGrava = new Button();
            textoConteudo = new TextBox();
            SuspendLayout();
            // 
            // botaoGrava
            // 
            botaoGrava.FlatStyle = FlatStyle.Flat;
            botaoGrava.Location = new Point(24, 512);
            botaoGrava.Name = "botaoGrava";
            botaoGrava.Size = new Size(98, 34);
            botaoGrava.TabIndex = 0;
            botaoGrava.Text = "GRAVAR";
            botaoGrava.UseVisualStyleBackColor = true;
            botaoGrava.Click += botaoGrava_Click;
            // 
            // textoConteudo
            // 
            textoConteudo.Font = new Font("Segoe UI", 14F, FontStyle.Regular, GraphicsUnit.Point);
            textoConteudo.Location = new Point(24, 12);
            textoConteudo.Multiline = true;
            textoConteudo.Name = "textoConteudo";
            textoConteudo.Size = new Size(597, 480);
            textoConteudo.TabIndex = 1;
            // 
            // Form1
            // 
            AutoScaleDimensions = new SizeF(7F, 15F);
            AutoScaleMode = AutoScaleMode.Font;
            ClientSize = new Size(656, 576);
            Controls.Add(textoConteudo);
            Controls.Add(botaoGrava);
            Name = "Form1";
            Text = "Editor de texto";
            Load += Form1_Load;
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private Button botaoGrava;
        private TextBox textoConteudo;
    }
}